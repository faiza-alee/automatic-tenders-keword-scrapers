import json

import pytest
from sqlalchemy import select

from app.ingest import upsert_tender
from app.models import Category, Keyword, ProcessingStatus, Tender
from app.nlp.extractors import TfidfExtractor, YakeExtractor, get_extractor
from app.nlp.pipeline import mark_for_reprocess, process_tender, run_pending_nlp
from tests.conftest import DATA
from tests.helpers import raw

SAMPLES = json.loads((DATA / "keyword_samples.json").read_text())


def test_taxonomy_classifies_each_sample(taxonomy):
    for s in SAMPLES:
        top = taxonomy.classify(s["title"], s["text"])
        assert top[0].name in s["categories"], (s["title"], [m.name for m in top])


def test_taxonomy_fallback_and_title_weight(taxonomy):
    assert taxonomy.classify("Miscellaneous", "nothing relevant here")[0].name == "Other"
    assert taxonomy.classify("Laptops", "")[0].score > taxonomy.classify("", "laptops")[0].score


def test_word_boundaries(taxonomy):
    names = [m.name for m in taxonomy.classify("Carpet cleaning", "")]
    assert "Vehicles and Transport" not in names       # 'car' must not match inside 'carpet'


@pytest.mark.parametrize("cls", [YakeExtractor, TfidfExtractor])
def test_extractors_return_meaningful_keywords(cls):
    text = SAMPLES[0]["title"] + ". " + SAMPLES[0]["text"] + " Sealed tenders are invited as per PPRA rules."
    kws = cls().extract(text, 10)
    terms = " ".join(k.term for k in kws)
    assert kws and all(0 <= k.score <= 1 for k in kws)
    assert "laptop" in terms or "printer" in terms
    assert not any(k.term in ("tenders", "ppra", "rules") for k in kws)   # boilerplate filtered


def test_unknown_method():
    with pytest.raises(ValueError):
        get_extractor("magic")


def test_pipeline_stores_keywords_categories_and_traceability(session, taxonomy, settings):
    upsert_tender(session, raw(title=SAMPLES[0]["title"], description=SAMPLES[0]["text"]))
    session.commit()
    res = run_pending_nlp(session, taxonomy=taxonomy, settings=settings)
    assert res == {"processed": 1, "failed": 0}
    t = session.scalar(select(Tender))
    assert t.description == SAMPLES[0]["text"]                       # original text preserved
    ranked = sorted(t.category_links, key=lambda c: -c.score)
    assert ranked[0].category.name == "IT Equipment and Computer Hardware"      # primary category
    assert ranked[0].matched_terms and len(ranked) <= 3
    assert t.keyword_links and all(k.method.startswith("yake") and "taxonomy-" in k.method for k in t.keyword_links)
    assert any(k.snippet for k in t.keyword_links)
    assert t.processing.nlp_status == "done" and t.processing.nlp_method
    assert session.scalar(select(Category).where(Category.name == "Other")) is not None


def test_second_run_does_nothing_until_content_changes(session, taxonomy, settings):
    upsert_tender(session, raw(title="Supply of laptops", description="laptops")); session.commit()
    run_pending_nlp(session, taxonomy=taxonomy, settings=settings)
    assert run_pending_nlp(session, taxonomy=taxonomy, settings=settings) == {"processed": 0, "failed": 0}
    upsert_tender(session, raw(title="Road construction and bridge repair", description="road construction and bridge repair")); session.commit()
    assert run_pending_nlp(session, taxonomy=taxonomy, settings=settings)["processed"] == 1
    t = session.scalar(select(Tender))
    assert max(t.category_links, key=lambda c: c.score).category.name == "Construction and Road Maintenance"
    assert session.scalar(select(Keyword).where(Keyword.term == "laptops")) is not None  # vocabulary kept, link removed
    assert "laptops" not in [k.keyword.term for k in t.keyword_links]


def test_forced_reprocess(session, taxonomy, settings):
    upsert_tender(session, raw()); session.commit()
    run_pending_nlp(session, taxonomy=taxonomy, settings=settings)
    assert mark_for_reprocess(session) == 1
    assert run_pending_nlp(session, taxonomy=taxonomy, settings=settings)["processed"] == 1


class Boom(YakeExtractor):
    def extract(self, text, top_n=15):
        if "poison" in text:
            raise RuntimeError("model exploded")
        return super().extract(text, top_n)


def test_failure_is_isolated_recorded_and_retried(session, taxonomy, settings):
    upsert_tender(session, raw(ref="A", title="poison pill laptops")); upsert_tender(session, raw(ref="B", title="Supply of laptops"))
    session.commit()
    ex = Boom()
    res = run_pending_nlp(session, ex, taxonomy, settings)
    assert res == {"processed": 1, "failed": 1}
    bad = session.scalar(select(ProcessingStatus).where(ProcessingStatus.nlp_status == "failed"))
    assert bad.attempts == 1 and "model exploded" in bad.last_error
    run_pending_nlp(session, ex, taxonomy, settings); run_pending_nlp(session, ex, taxonomy, settings)
    assert bad.attempts == settings.max_nlp_attempts
    assert run_pending_nlp(session, ex, taxonomy, settings) == {"processed": 0, "failed": 0}   # gives up, no endless loop


def test_scores_are_plain_python_floats_not_numpy():
    """psycopg2 cannot store numpy.float64 ('schema "np" does not exist'); SQLite hides this, so check the type itself."""
    text = SAMPLES[0]["title"] + ". " + SAMPLES[0]["text"]
    for ex in (YakeExtractor(), TfidfExtractor()):
        kws = ex.extract(text, 10)
        assert kws and all(type(k.score) is float for k in kws), ex.name


def test_pipeline_stores_plain_floats(session, taxonomy, settings):
    upsert_tender(session, raw(title=SAMPLES[0]["title"], description=SAMPLES[0]["text"])); session.commit()
    run_pending_nlp(session, taxonomy=taxonomy, settings=settings)
    t = session.scalar(select(Tender))
    assert all(type(k.score) is float for k in t.keyword_links) and all(type(c.score) is float for c in t.category_links)


def test_pdf_header_and_scanner_stamps_are_removed_from_text(session):
    from app.models import TenderDocument
    from app.nlp.pipeline import build_text
    t = upsert_tender(session, raw(description="d")).tender
    t.documents.append(TenderDocument(url="http://x/a.pdf", text="Public Procurement Regulatory Authority (PPRA)\nScanned with CamScanner\nSupply of laptops"))
    _, body = build_text(t)
    assert "CamScanner" not in body and "Regulatory Authority" not in body and "laptops" in body
